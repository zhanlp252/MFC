package io.github.lovelybowen.database.support;

/**
 * @author: Bowen huang
 * @date: 2020/06/21
 */
public class DbConstant {


    public static final Integer DB_NOT_DELETED = 0;
    public static final Integer DB_DELETED = 1;

    public static final Integer DB_STATUS_NORMAL = 1;

}
